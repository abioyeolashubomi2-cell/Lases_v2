exports.handler = async (event) => {
 if (event.httpMethod !== "POST") return {statusCode:405,body:"Method Not Allowed"};
 const token=process.env.TELEGRAM_BOT_TOKEN, chatId=process.env.TELEGRAM_CHAT_ID;
 if (!token || !chatId) return {statusCode:500,body:"Notification service is not configured."};
 let data; try {data=JSON.parse(event.body||"{}");} catch {return {statusCode:400,body:"Invalid request."};}
 const messages={page_open:"🔔 A visitor opened your LASSES link.",continued:"👀 A visitor pressed CONTINUE on LASSES."};
 const message=messages[data.event]; if(!message) return {statusCode:400,body:"Unsupported event."};
 try {const r=await fetch(`https://api.telegram.org/bot${token}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:chatId,text:message})}); if(!r.ok)return {statusCode:502,body:"Telegram notification failed."}; return {statusCode:200,body:"OK"};} catch {return {statusCode:502,body:"Notification delivery failed."};}
};